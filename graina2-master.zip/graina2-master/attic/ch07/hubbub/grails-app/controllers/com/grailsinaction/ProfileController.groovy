package com.grailsinaction

class ProfileController {

    def scaffold = true
}
