package com.grailsinaction

class TagController {

    def scaffold = true
}
