package com.grailsinaction

import grails.test.*

class PostTests extends grails.test.GrailsUnitTestCase {

    void testSomething() {

    }
}
