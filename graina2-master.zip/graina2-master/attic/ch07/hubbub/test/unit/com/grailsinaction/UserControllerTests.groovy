package com.grailsinaction

import grails.test.*

class UserControllerTests extends grails.test.GrailsUnitTestCase {

    void testSomething() {

    }
}
