package com.grailsinaction

import grails.test.*

class TagControllerTests extends grails.test.GrailsUnitTestCase {

    void testSomething() {

    }
}
