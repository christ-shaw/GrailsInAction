package com.grailsinaction.legacy.db

constraints = {
	name(size: 4..30)
}