class BranchController {

    def scaffold = com.grailsinaction.legacy.db.Branch
}
