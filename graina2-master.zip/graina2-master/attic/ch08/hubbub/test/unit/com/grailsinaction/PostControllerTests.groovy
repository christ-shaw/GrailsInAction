package com.grailsinaction

import grails.test.*

class PostControllerTests extends grails.test.GrailsUnitTestCase {

    void testSomething() {

    }
}
