class BrowserControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
