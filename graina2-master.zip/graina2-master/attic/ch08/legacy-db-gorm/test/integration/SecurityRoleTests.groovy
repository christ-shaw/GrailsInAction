class SecurityRoleTests extends GroovyTestCase {

    void testSomething() {

    }
}
