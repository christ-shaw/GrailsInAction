class ResourceTypeControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
