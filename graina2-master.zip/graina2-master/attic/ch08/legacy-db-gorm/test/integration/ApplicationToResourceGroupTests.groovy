class ApplicationToResourceGroupTests extends GroovyTestCase {

    void testSomething() {

    }
}
