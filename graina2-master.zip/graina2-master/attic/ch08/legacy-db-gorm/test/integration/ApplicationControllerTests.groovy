class ApplicationControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
