class ResourceOwnerTests extends GroovyTestCase {

    void testSomething() {

    }
}
