class ResourceTypeTests extends GroovyTestCase {

    void testSomething() {

    }
}
