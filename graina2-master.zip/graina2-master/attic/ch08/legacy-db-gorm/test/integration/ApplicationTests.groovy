class ApplicationTests extends GroovyTestCase {

    void testSomething() {

    }
}
