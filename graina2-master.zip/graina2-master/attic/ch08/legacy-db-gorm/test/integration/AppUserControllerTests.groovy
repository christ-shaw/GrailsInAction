class AppUserControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
