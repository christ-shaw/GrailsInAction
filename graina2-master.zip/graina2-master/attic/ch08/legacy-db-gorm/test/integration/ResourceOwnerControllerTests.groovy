class ResourceOwnerControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
