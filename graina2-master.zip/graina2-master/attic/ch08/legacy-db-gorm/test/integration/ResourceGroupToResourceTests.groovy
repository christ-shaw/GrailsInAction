class ResourceGroupToResourceTests extends GroovyTestCase {

    void testSomething() {

    }
}
