class SecurityRoleToResourceGroupTests extends GroovyTestCase {

    void testSomething() {

    }
}
