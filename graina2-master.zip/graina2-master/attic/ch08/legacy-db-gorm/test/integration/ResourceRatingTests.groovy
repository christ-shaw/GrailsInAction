class ResourceRatingTests extends GroovyTestCase {

    void testSomething() {

    }
}
