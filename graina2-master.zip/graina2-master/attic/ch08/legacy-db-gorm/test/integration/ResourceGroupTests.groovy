class ResourceGroupTests extends GroovyTestCase {

    void testSomething() {

    }
}
