class ResourceTests extends GroovyTestCase {

    void testSomething() {

    }
}
