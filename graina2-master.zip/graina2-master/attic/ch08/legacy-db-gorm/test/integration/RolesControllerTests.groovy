class RolesControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
