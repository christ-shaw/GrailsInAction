class ApplicationToResourceTests extends GroovyTestCase {

    void testSomething() {

    }
}
