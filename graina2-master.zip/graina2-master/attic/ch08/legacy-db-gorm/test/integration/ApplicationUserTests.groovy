class ApplicationUserTests extends GroovyTestCase {

    void testSomething() {

    }
}
