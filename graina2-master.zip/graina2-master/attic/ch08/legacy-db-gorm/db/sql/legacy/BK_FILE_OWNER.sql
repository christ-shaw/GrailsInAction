insert into BK_FILE_OWNER (FILE_OWNER_ID, OWNER_NM, OWNER_DESC) values (1, 'Joe Phillips', 'No description entered');
insert into BK_FILE_OWNER (FILE_OWNER_ID, OWNER_NM, OWNER_DESC) values (2, 'Steve Jones', 'No description entered');
insert into BK_FILE_OWNER (FILE_OWNER_ID, OWNER_NM, OWNER_DESC) values (3, 'Mary Phelps', 'No description entered');