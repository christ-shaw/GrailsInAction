insert into BK_SECTION (SECTION_ID, SECTION_NM, START_DT, END_DT) values (1, 'SectionNorth', '2006-12-05', '9999-12-30');
insert into BK_SECTION (SECTION_ID, SECTION_NM, START_DT, END_DT) values (2, 'SectionSouth', '2006-12-05', '9999-12-30');
insert into BK_SECTION (SECTION_ID, SECTION_NM, START_DT, END_DT) values (3, 'SectionWest', '2006-12-05', '9999-12-30');
insert into BK_SECTION (SECTION_ID, SECTION_NM, START_DT, END_DT) values (4, 'SectionEast',  '2006-12-05', '9999-12-30');

