
-- release any lock we have on the hsqldb process
SHUTDOWN;