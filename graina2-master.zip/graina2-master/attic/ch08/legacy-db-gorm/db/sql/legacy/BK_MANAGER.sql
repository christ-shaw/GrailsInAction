insert into BK_MANAGER (BRANCH_NM, LOCATION_ID, NAME, MGMT_RATING_VAL) values ('Westside', 1, 'John West', 3);
insert into BK_MANAGER (BRANCH_NM, LOCATION_ID, NAME, MGMT_RATING_VAL) values ('Northside', 1, 'Peter North', 2);
insert into BK_MANAGER (BRANCH_NM, LOCATION_ID, NAME, MGMT_RATING_VAL) values ('Eastside', 1, 'Mary East', 3);
insert into BK_MANAGER (BRANCH_NM, LOCATION_ID, NAME, MGMT_RATING_VAL) values ('Southside', 1, 'Karen South', 2);