insert into BK_BRANCH (BRANCH_NM) values ('Northside');
insert into BK_BRANCH (BRANCH_NM) values ('Southside');
insert into BK_BRANCH (BRANCH_NM) values ('Westside');
insert into BK_BRANCH (BRANCH_NM) values ('Eastside');
