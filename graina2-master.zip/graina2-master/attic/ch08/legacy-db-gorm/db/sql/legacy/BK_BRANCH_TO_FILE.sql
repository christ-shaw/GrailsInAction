insert into BK_BRANCH_TO_FILE (FILE_ID, BRANCH_NM) values (1, 'Northside');
insert into BK_BRANCH_TO_FILE (FILE_ID, BRANCH_NM) values (2, 'Southside');
insert into BK_BRANCH_TO_FILE (FILE_ID, BRANCH_NM) values (3, 'Westside');
