insert into BK_FILE_TYPE (FILE_TYPE_CD, FILE_TYPE_NM, FILE_TYPE_DESC) values ('C', 'Commercial in Confidence', 'No description entered');
insert into BK_FILE_TYPE (FILE_TYPE_CD, FILE_TYPE_NM, FILE_TYPE_DESC) values ('N', 'No Classification Given', 'No description entered');
