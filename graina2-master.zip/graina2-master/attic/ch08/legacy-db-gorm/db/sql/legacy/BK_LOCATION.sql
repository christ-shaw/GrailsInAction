insert into BK_LOCATION (LOCATION_ID, LOCATION_NM) values (1, 'Westside Mall');
insert into BK_LOCATION (LOCATION_ID, LOCATION_NM) values (2, 'Northside Mall');
