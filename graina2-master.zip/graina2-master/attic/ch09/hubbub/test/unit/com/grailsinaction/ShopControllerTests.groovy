package com.grailsinaction

import grails.test.*

class ShopControllerTests extends grails.test.GrailsUnitTestCase {

    void testSomething() {

    }
}
