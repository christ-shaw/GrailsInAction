# The Attic

This folder contains the source code from the first edition of the book. Readers can safely ignore it. It was included as a development aid for the authors.
